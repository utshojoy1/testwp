﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MatrimonialPotalSystemCSharp
{
    public partial class Home2 : Form
    {
        public Home2()
        {
            InitializeComponent();
        }

        private void searchInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddInformation obj = new AddInformation();
            obj.ShowDialog();
        }

        private void deleteInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchInformation obj1 = new MatrimonialPotalSystemCSharp.SearchInformation();
            obj1.ShowDialog();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Form1 obj2 = new MatrimonialPotalSystemCSharp.Form1();
            obj2.ShowDialog();
        }
    }
}
