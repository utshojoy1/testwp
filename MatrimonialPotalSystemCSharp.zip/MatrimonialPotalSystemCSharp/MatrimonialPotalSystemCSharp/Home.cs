﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MatrimonialPotalSystemCSharp
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void searchInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchInfoA obj = new MatrimonialPotalSystemCSharp.SearchInfoA();
            obj.ShowDialog();
        }

        private void deleteInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteInfoA obj1 = new DeleteInfoA();
            obj1.ShowDialog();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Form1 obj2 = new Form1();
            obj2.ShowDialog();
        }
    }
}
