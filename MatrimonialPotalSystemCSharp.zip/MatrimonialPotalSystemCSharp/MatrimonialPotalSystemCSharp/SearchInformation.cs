﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MatrimonialPotalSystemCSharp
{
    public partial class SearchInformation : Form
    {
        public SearchInformation()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\dell\Documents\Visual Studio 2015\Projects\MatrimonialPotalSystemCSharp\MatrimonialPotalSystemCSharp\matro.mdf;Integrated Security=True");

            con.Open();
            if (textBox1.Text != "")
            {
                try
                {
                    string getCust = "select f_name,l_name,gen,dob,age,m_tounge,religion,fa_name,m_name,f_occu,m_occu,mobile,gradu,p_gradu,comp,desig,salary from m_user where id=" + Convert.ToInt32(textBox1.Text) + " ;";

                    SqlCommand cmd = new SqlCommand(getCust, con);
                    SqlDataReader dr;
                    dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        label24.Text = dr.GetValue(0).ToString();
                        label25.Text = dr.GetValue(1).ToString();
                        label26.Text = dr.GetValue(2).ToString();
                        label27.Text = dr.GetValue(3).ToString();
                        label28.Text = dr.GetValue(4).ToString();
                        label29.Text = dr.GetValue(5).ToString();
                        label30.Text = dr.GetValue(6).ToString();
                        label32.Text = dr.GetValue(7).ToString();
                        label33.Text = dr.GetValue(8).ToString();
                        label34.Text = dr.GetValue(9).ToString();
                        label35.Text = dr.GetValue(10).ToString();
                        label36.Text = dr.GetValue(11).ToString();
                        label37.Text = dr.GetValue(12).ToString();
                        label38.Text = dr.GetValue(13).ToString();
                        label39.Text = dr.GetValue(14).ToString();
                        label40.Text = dr.GetValue(15).ToString();
                        label41.Text = dr.GetValue(16).ToString();
                    }
                    else
                    {
                        MessageBox.Show(" Sorry, This ID, " + textBox1.Text + " User Record is not Available.   ");
                        textBox1.Text = "";
                    }
                }
                catch (SqlException excep)
                {
                    MessageBox.Show(excep.Message);
                }
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label24.Text = "";
            label25.Text = "";
            label26.Text = "";
            label27.Text = "";
            label28.Text = "";
            label29.Text = "";
            label30.Text = "";
            label32.Text = "";
            label33.Text = "";
            label34.Text = "";
            label35.Text = "";
            label36.Text = "";
            label37.Text = "";
            label38.Text = "";
            label39.Text = "";
            label40.Text = "";
            label41.Text = "";
            
        }
    }
}
